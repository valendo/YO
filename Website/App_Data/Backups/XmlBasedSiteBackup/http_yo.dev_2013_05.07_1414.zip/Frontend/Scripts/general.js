﻿$(document).ready(function () {
    $('.top-menu li.has-sub').click(function () {
        $('.top-menu li.has-sub .sub-menu').toggle();
    });
});